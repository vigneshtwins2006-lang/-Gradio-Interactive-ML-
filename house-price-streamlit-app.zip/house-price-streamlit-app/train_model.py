"""
Train the house price models and save them with joblib.

Run once before launching the app:
    python train_model.py
"""

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import accuracy_score, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier


def load_data():
    """Load California Housing; fall back to synthetic data if offline."""
    try:
        from sklearn.datasets import fetch_california_housing

        df = fetch_california_housing(as_frame=True).frame.rename(
            columns={"MedHouseVal": "Price"}
        )
        df["Price"] = df["Price"] * 100000
        return df, "California Housing"
    except Exception:
        rng = np.random.default_rng(42)
        n = 1000
        df = pd.DataFrame(
            {
                "Area_sqft": rng.integers(500, 4000, n),
                "Bedrooms": rng.integers(1, 6, n),
                "Bathrooms": rng.integers(1, 4, n),
                "Age_years": rng.integers(0, 50, n),
                "Distance_to_city_km": rng.uniform(1, 30, n).round(1),
            }
        )
        df["Price"] = (
            df["Area_sqft"] * 120
            + df["Bedrooms"] * 8000
            + df["Bathrooms"] * 6000
            - df["Age_years"] * 700
            - df["Distance_to_city_km"] * 1500
            + rng.normal(0, 15000, n)
        ).round(2)
        return df, "Synthetic House Prices"


def main():
    df, dataset_name = load_data()
    X = df.drop(columns="Price")
    y = df["Price"]

    # Regression: predict price
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    regressor = LinearRegression().fit(X_train, y_train)
    pred = regressor.predict(X_test)
    mse = mean_squared_error(y_test, pred)
    r2 = r2_score(y_test, pred)

    # Classification: High (1) vs Low (0) price, split at the median
    median_price = float(y.median())
    y_cls = (y > median_price).astype(int)
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(
        X, y_cls, test_size=0.2, random_state=42, stratify=y_cls
    )
    classifier = DecisionTreeClassifier(max_depth=5, random_state=42).fit(
        Xc_train, yc_train
    )
    acc = accuracy_score(yc_test, classifier.predict(Xc_test))

    # Slider ranges for the app (1st-99th percentile avoids extreme outliers)
    stats = {}
    for col in X.columns:
        lo, hi = float(X[col].quantile(0.01)), float(X[col].quantile(0.99))
        default = float(X[col].median())
        if (X[col] % 1 == 0).all():  # integer-valued column -> integer slider
            lo, hi, default = round(lo), round(hi), round(default)
        stats[col] = {"min": float(lo), "max": float(hi), "default": float(default)}

    bundle = {
        "regressor": regressor,
        "classifier": classifier,
        "features": list(X.columns),
        "stats": stats,
        "median_price": median_price,
        "metrics": {"mse": mse, "rmse": float(np.sqrt(mse)), "r2": r2, "accuracy": acc},
        "dataset": dataset_name,
        "n_samples": len(df),
        "importances": dict(zip(X.columns, classifier.feature_importances_.tolist())),
        "coefficients": dict(zip(X.columns, regressor.coef_.tolist())),
    }
    joblib.dump(bundle, "model.joblib")

    print(f"Dataset      : {dataset_name} ({len(df)} rows)")
    print(f"Regression   : MSE={mse:,.2f}  RMSE={np.sqrt(mse):,.2f}  R2={r2:.4f}")
    print(f"Classification: Accuracy={acc:.4f}")
    print("Saved model.joblib")


if __name__ == "__main__":
    main()

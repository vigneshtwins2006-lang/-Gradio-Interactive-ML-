"""
House Price Predictor - Streamlit web app
Run with:  streamlit run app.py
"""

from pathlib import Path

import joblib
import pandas as pd
import streamlit as st

st.set_page_config(page_title="House Price Predictor", page_icon="🏠", layout="wide")

MODEL_PATH = Path(__file__).parent / "model.joblib"


@st.cache_resource
def load_bundle():
    """Load the trained models once and cache them."""
    if not MODEL_PATH.exists():
        # Train automatically on first run (useful on Streamlit Cloud)
        import train_model

        train_model.main()
    return joblib.load(MODEL_PATH)


bundle = load_bundle()
features = bundle["features"]
stats = bundle["stats"]
metrics = bundle["metrics"]
regressor = bundle["regressor"]
classifier = bundle["classifier"]
median_price = bundle["median_price"]


def pretty(name: str) -> str:
    return name.replace("_", " ")


# ----------------------------- Header -----------------------------
st.title("🏠 House Price Predictor")
st.caption(
    "Interactive ML web app built with Streamlit and Scikit-Learn. "
    "Move the sliders in the sidebar to get a real-time prediction."
)

# ----------------------------- Sidebar inputs ---------------------
st.sidebar.header("Input Features")
inputs = {}
for col in features:
    s = stats[col]
    lo, hi, default = s["min"], s["max"], s["default"]
    is_int = all(float(v).is_integer() for v in (lo, hi, default))
    if is_int:
        inputs[col] = st.sidebar.slider(
            pretty(col), int(lo), int(hi), int(default)
        )
    else:
        step = round((hi - lo) / 100, 4) or 0.01
        inputs[col] = st.sidebar.slider(
            pretty(col), float(lo), float(hi), float(default), step=step
        )

if st.sidebar.button("Reset to defaults"):
    st.rerun()

input_df = pd.DataFrame([inputs])[features]

# ----------------------------- Prediction -------------------------
price = float(regressor.predict(input_df)[0])
category = int(classifier.predict(input_df)[0])
confidence = float(classifier.predict_proba(input_df)[0][category])

tab_predict, tab_perf, tab_about = st.tabs(
    ["🔮 Prediction", "📊 Model Performance", "ℹ️ About"]
)

with tab_predict:
    c1, c2, c3 = st.columns(3)
    c1.metric("Predicted Price", f"${max(price, 0):,.0f}")
    c2.metric("Price Category", "High 📈" if category == 1 else "Low 📉")
    c3.metric("Classifier Confidence", f"{confidence:.0%}")

    if price < 0:
        st.warning(
            "The linear model predicted a negative price for this combination of "
            "inputs, so it is shown as $0. Try values closer to the typical range."
        )

    st.progress(
        min(max(price / (median_price * 2), 0.0), 1.0),
        text=f"Compared with the median price of ${median_price:,.0f}",
    )

    left, right = st.columns(2)
    with left:
        st.subheader("Your inputs")
        st.dataframe(
            input_df.rename(columns=pretty).T.rename(columns={0: "Value"}),
            use_container_width=True,
        )
    with right:
        st.subheader("Feature importance (Decision Tree)")
        imp = pd.Series(bundle["importances"]).rename(index=pretty).sort_values()
        st.bar_chart(imp)

with tab_perf:
    st.subheader("Evaluation on the held-out test set")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("R² Score", f"{metrics['r2']:.3f}")
    m2.metric("RMSE", f"${metrics['rmse']:,.0f}")
    m3.metric("MSE", f"{metrics['mse']:,.0f}")
    m4.metric("Classifier Accuracy", f"{metrics['accuracy']:.1%}")
    st.caption(
        f"Dataset: {bundle['dataset']} ({bundle['n_samples']:,} rows), "
        "80/20 train-test split."
    )
    st.subheader("Linear Regression coefficients")
    st.bar_chart(pd.Series(bundle["coefficients"]).rename(index=pretty))

with tab_about:
    st.markdown(
        """
**How it works**
1. `train_model.py` trains a Linear Regression (price) and a Decision Tree
   Classifier (High/Low price) and saves them with `joblib`.
2. `app.py` loads the saved model and builds sliders from the data ranges.
3. Every slider change re-runs the prediction instantly.

**Tech stack:** Python, Pandas, Scikit-Learn, Joblib, Streamlit

This is a learning project. Predictions come from simple models and should not
be used for real property valuation.
"""
    )

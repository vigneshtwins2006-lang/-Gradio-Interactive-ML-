# 🏠 House Price Predictor – Streamlit ML Web App

An interactive machine learning web app that predicts house prices in real time.
Built with **Streamlit** and **Scikit-Learn** as part of the InternCircle Data Science internship (Task 5).

## Features
- **Streamlit interface** with sidebar sliders for every input feature
- **Model loading with joblib** – trained models are saved once and loaded (cached) by the app
- **Interactive prediction display** – predicted price, High/Low category and classifier confidence update instantly
- Model performance tab (R², RMSE, MSE, Accuracy) and feature importance charts

## Models
| Model | Purpose | Metrics |
|-------|---------|---------|
| Linear Regression | Predict house price | MSE, RMSE, R² |
| Decision Tree Classifier | Classify High / Low price | Accuracy |

## Project Structure
```
house-price-streamlit-app/
├── app.py            # Streamlit web app
├── train_model.py    # Trains models and saves model.joblib
├── requirements.txt
└── README.md
```

## Run Locally
```bash
pip install -r requirements.txt
python train_model.py        # creates model.joblib
streamlit run app.py
```
Open http://localhost:8501 in your browser.

## Deploy on Streamlit Community Cloud (free)
1. Push this folder to a public GitHub repository.
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click **New app**, choose your repo, branch `main`, and main file `app.py`.
4. Click **Deploy**. The app trains the model automatically on first launch if `model.joblib` is missing.
5. Copy the public URL and add it to this README and your submission.

**Live demo:** _add your deployed link here_

## Tech Stack
Python · Pandas · Scikit-Learn · Joblib · Streamlit

## Disclaimer
Educational project. Predictions are not suitable for real property valuation.
